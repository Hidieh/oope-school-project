/**
 * OOPE 2018 harkkatyö
 * Ohjelman käyttöliittymän ajava luokka
 * @author Heidi Happonen, 424364, Happonen.Heidi.K@student.uta.fi
 */
 
import oope2018ht.kayttoliittyma.Kayttoliittyma;

public class Oope2018HT {

   public static void main(String[] args) {
      Kayttoliittyma kayttis = new Kayttoliittyma();
      kayttis.aja();
   }
   
}
